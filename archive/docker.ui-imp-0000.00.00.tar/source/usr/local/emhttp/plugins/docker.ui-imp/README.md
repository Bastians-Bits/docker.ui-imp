####Docker UI Improvements####
Improvements to the Docker UI and hence unsability
